# Security & Correctness Audit — Addendum (Pass 2)

Re-verified every claim in `SECURITY_AUDIT.md` against the actual code (not
just the comments describing the fix) and traced every code path that
handles auth, money/quota, and logging. Findings 1–16 in the original
document all check out as genuinely fixed. This pass found **four
additional issues that were either missed entirely or only half-fixed** —
i.e. the comment says "fixed" but the code doesn't fully do what the
comment claims. All four are now fixed in this codebase; see the inline
comments at each site for detail.

---

## 17. Auth-failure path bypassed the rate limiter entirely (High — brute force / DoS)

**Where:** `app/auth.py`

**Evidence:** `check_rate_limit()` is only ever called *after*
`db.verify_api_key()` succeeds. A missing `X-API-Key` header or an invalid
key returns 401 before the limiter is ever reached — so credential-guessing
traffic was completely unthrottled, on both the "no key" and "wrong key"
branches. Finding 3 in the original audit fixed the limiter's internal
no-op bug and wired it into the success path, but didn't cover this.

**Impact:** unlimited automated guessing against `X-API-Key`, and no per-IP
signal at all to notice it happening. Practically mitigated by key entropy
(~190 bits — see `scripts/generate_api_key.py`), so this is defense-in-depth
rather than the primary control, but a "rate limiter" that only limits
requests from keys that already work isn't doing its stated job.

**Fix:** new `RateLimiter.check_auth_failure_limit(ip)`, a separate
IP-scoped Redis counter, called on both failure branches in
`auth.verify_api_key()` before the 401 is raised.

---

## 18. Tax validator sent `country` upstream but silently dropped `tax_id` (High — the core compliance claim was still fiction)

**Where:** `app/circuit_breaker.py`

**Evidence:** Finding 4 in the original audit correctly identified that
`validate_tax_id()` used to unconditionally return `CLEARED` without
calling anything, and fixed that. But the replacement
`_call_upstream(tax_id, country)` accepted `tax_id` as a parameter and then
never put it on the outgoing request — only `country` was sent as a query
param. That means the response never depended on which tax ID was
submitted: `BE0123456789` and `BE0000000000` for the same country got an
identical result. The call *looked* real (it hits the network, respects
the circuit breaker, retries, etc.) but wasn't actually checking the thing
a tax-ID validator exists to check.

**Impact:** for a product whose entire premise is compliance clearance,
this is the same "verification didn't happen" problem as before, one layer
deeper and harder to notice on a code read because the HTTP call is real.

**Fix:** `tax_id` is now included in the upstream request. Also added
`is_stub_upstream()` / a startup guard (see #19) because sending the right
parameters to `https://httpbin.org/delay/1` (the shipped default) still
validates nothing — httpbin just echoes 200. Point
`TAX_VALIDATION_API_URL` at a real authoritative service (e.g. the EU VIES
API for VAT numbers) before this is a genuine compliance check.

---

## 19. Placeholder tax-validation URL could silently ship to production (Medium/High — depends on deployment)

**Where:** `app/config.py`, `app/circuit_breaker.py`, `app/main.py`

**Evidence:** `TAX_VALIDATION_API_URL` defaults to `https://httpbin.org/delay/1`
— a public echo endpoint with no relationship to tax authorities. Nothing
stopped a deploy from running with `ENVIRONMENT=production` and this
default still in place, silently clearing every invoice against a service
that validates nothing.

**Fix:** `is_stub_upstream()` detects the placeholder host. `validate_tax_id()`
now forces `DEGRADED` (never a false `CLEARED`) whenever it's in use, and
`main.py`'s `lifespan` refuses to start at all when
`ENVIRONMENT=production` and the placeholder is still configured — same
fail-loudly principle the original audit already applied to
`SEED_TEST_API_KEY`.

---

## 20. Monthly quota (`monthly_limit`) was never enforced (Medium — billing/revenue integrity)

**Where:** `app/main.py`, `app/dashboard_routes.py`

**Evidence:** `api_accounts.monthly_limit` and `used_requests` exist in the
schema, are incremented on every clearance, and are displayed on the
dashboard (`quota_remaining`, `quota_percentage`) — but nothing anywhere
compares them. A "starter" tier account was functionally unlimited, bounded
only by the unrelated 60/min burst rate limit.

**Impact:** for a tiered SaaS product this is a revenue-integrity gap, not
just a cosmetic one — the dashboard tells a customer they're at 140% of
quota while the API keeps serving them at full speed.

**Fix:** `/v1/clearance/preflight` now checks `used_requests >= monthly_limit`
before processing and returns `402 Payment Required` with a clear message
if exceeded.

---

## 21. `SensitiveDataRedactor` was fixed internally but never attached anywhere (Medium — log hygiene, the fix didn't actually apply)

**Where:** `app/log_sanitizer.py`, `app/main.py`

**Evidence:** Finding 16 in the original audit correctly fixed the
filter's *internal* bug (patterns built but unused inside `filter()`), but
the filter object itself was never instantiated or attached to any
`Logger` or `Handler` anywhere in the codebase — `grep -rn "addFilter"`
returns nothing in the prior version. A correctly-implemented redaction
filter that's never wired in behaves identically to a broken one: nothing
gets redacted either way. Compounding this, the app has two independent
logging systems — stdlib `logging.getLogger(__name__)` (used in
`circuit_breaker.py`, `rate_limiter.py`, `database.py`, `health.py`) and
`structlog` (used only in `main.py`) — so attaching the filter to just one
would still leave the other uncovered.

**Fix:** the filter is now attached to the root stdlib logger's handler
(covers all four stdlib-logging modules), and a structlog-native processor
(`redact_structlog_event`, same regex patterns) is added to
`structlog.configure(processors=[...])` to cover `main.py`'s logger too.

---

## Not changed, flagged for awareness

- **`dateutil.parser.parse(v, dayfirst=True)`** in `models.py`: reasonable
  for the Belgium/France-first use case, but for a client submitting
  US-style `MM/DD/YYYY` dates this will silently parse the day and month
  swapped rather than erroring, because `dayfirst` doesn't validate — it
  only breaks ties when a date is ambiguous. Not a code bug, but worth
  requiring ISO 8601 (`YYYY-MM-DD`) input from integrators, or validating
  the parsed date isn't nonsensical, if this expands beyond EU-format
  clients.
- **`localStorage`-stored API key**: still an open item from the original
  audit's own "Known limitation" section (session-cookie migration) — not
  revisited here since Finding 1 (the XSS vector) is fixed, but it remains
  the top architectural follow-up.

---

# Pass 3 — Enterprise readiness / "will this break an existing client"

Everything above is a correctness or security fix. None of them were
checked against a separate question that matters just as much for a real
enterprise customer: **does turning this on break something that used to
work?** Two of the fixes above are exactly that kind of change if shipped
without a compatibility story. Both are now fixed structurally; two more
are flagged as decisions for you rather than code changes, because they're
policy, not bugs.

## 22. No idempotency support — retries silently duplicated audit records and quota (High)

**Where:** `app/main.py`, `app/database.py`, `migrations/002_idempotency.sql`

**Evidence:** every enterprise HTTP client library retries on timeout by
default. `clearance_id = f"CLR-{uuid.uuid4()}"` was generated fresh on
every call with no dedupe key, and `invoice_number` has no unique
constraint — so a client's retried request created a **second** audit log
row for the same real-world invoice and incremented `used_requests` a
second time. For a product whose value proposition is an accurate audit
trail, silently-duplicated audit records are a correctness problem in
their own right, on top of the double-billed quota.

**Fix:** optional `Idempotency-Key` request header on
`/v1/clearance/preflight`. A repeated key for the same account returns the
originally-stored response verbatim (`Idempotency-Replayed: true` response
header) with no new audit row and no additional quota consumed. Stored in
Postgres (not Redis) since this needs to survive a cache restart — it's a
correctness guarantee, not a performance optimization. **Backward
compatible by construction**: omitting the header preserves the exact
previous behavior, so this can only make adopting clients safer, not break
anyone.

## 23. Three different JSON shapes for errors (Medium — breaks client error handling)

**Where:** `app/main.py`

**Evidence:** `401`/`402`/`429` returned FastAPI's default `{"detail": "..."}`;
the catch-all 500 handler returned `{"status", "message", "reference_id"}`;
Pydantic validation `422`s returned a third, library-specific shape. A
client writing one error handler against "the API's error contract" had to
special-case three different response bodies depending on which failure
mode they hit.

**Fix:** added handlers for `HTTPException` and `RequestValidationError` so
every error path now returns the same envelope
(`status` / `message` / `reference_id`, with `errors` added for validation
failures so field-level detail isn't lost). Status codes and headers
(e.g. `Retry-After` on 429) are preserved exactly as before — only the body
shape changed.

## 24. Quota enforcement and rate limits are new behavior for anyone already integrated (policy decision, not a bug)

**Where:** `app/main.py` (quota), `app/rate_limiter.py` (both limiters)

Finding 20 (quota) and Finding 17 (auth-failure rate limit) from Pass 2 are
both **correct fixes that are also breaking changes** if flipped on for an
account that's been running against the unenforced version. Two decisions
worth making deliberately rather than by accident:

- **Quota**: consider a grace period (log-and-allow past the limit for N
  days, or a soft-cap warning header before the hard 402) before enforcing
  against *existing* accounts, even though enforcing on new accounts from
  day one is straightforward.
- **Auth-failure rate limit**: the current default
  (`AUTH_FAILURE_LIMIT_PER_MINUTE = 20`) is per source IP. If any client
  sits behind a corporate NAT/proxy where many employees share one egress
  IP, unrelated typos from other employees count against the same budget.
  Worth raising the default and/or documenting it as tunable per-deployment
  if you expect large enterprise clients behind shared egress.

## 25. Tax validation defaults to `DEGRADED` on every response until configured (customer-experience, not a bug)

**Where:** `app/circuit_breaker.py`, `app/config.py`

Finding 19 (Pass 2) makes the app refuse to boot in production against the
`httpbin.org` placeholder — correct and intentional, but worth surfacing
here too: **every clearance a client sees will read `DEGRADED` with a
"provisionally cleared" message until `TAX_VALIDATION_API_URL` is pointed
at a real service.** That's the honest behavior (better than a false
`CLEARED`), but from a new client's seat it can look like the product
launched broken rather than like the product is being careful. Worth
having the real upstream configured *before* the first client integration,
not discovered by a client after.

